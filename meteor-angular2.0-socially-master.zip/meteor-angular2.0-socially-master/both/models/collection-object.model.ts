export interface CollectionObject {
  _id?: string;
}