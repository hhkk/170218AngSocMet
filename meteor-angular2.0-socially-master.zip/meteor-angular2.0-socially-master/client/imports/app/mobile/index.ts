import {AppMobileComponent} from "./app.component.mobile";
import {PartiesListMobileComponent} from "./parties-list.component.mobile";

export const MOBILE_DECLARATIONS = [
  AppMobileComponent,
  PartiesListMobileComponent
];