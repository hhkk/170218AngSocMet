Let's create a purely static HTML page and then examine how we can turn this HTML code into a template that Angular will use to dynamically display the same result with any set of data.

Add this template HTML to `app.html`:

{{{diff_step 2.1}}}

Now, let's go to the [next step](/tutorials/angular2/dynamic-template) and learn how to dynamically generate the same list using Angular 2.
