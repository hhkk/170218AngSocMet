## ngUpgrade

[Click here](/tutorials/socially/angular1/migration-to-angular2) for the chapter explaining how to use both Angular 1.x and 2.0 in the same app and migrate gradually. 
