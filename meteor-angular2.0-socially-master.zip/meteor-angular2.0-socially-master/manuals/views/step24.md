[{]: <region> (header)
# Step 24: ngUpgrade and Migration to Angular2
[}]: #
[{]: <region> (body)
## ngUpgrade

[Click here](/tutorials/socially/angular1/migration-to-angular2) for the chapter explaining how to use both Angular 1.x and 2.0 in the same app and migrate gradually. 

[}]: #
[{]: <region> (footer)
[{]: <helper> (nav_step)
| [< Previous Step](step23.md) | [Next Step >](step25.md) |
|:--------------------------------|--------------------------------:|
[}]: #
[}]: #